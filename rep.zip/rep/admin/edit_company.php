<?

$CURRENT_FILE = 'edit_company';

include("init.php");
require_once($_SERVER['DOCUMENT_ROOT']."/models/user.php");
require_once($_SERVER['DOCUMENT_ROOT']."/models/offer.php");
require_once($_SERVER['DOCUMENT_ROOT']."/models/company.php");
$notify = "";

if((int) $_GET['id'] < 1){
    header("Location: /admin/");
    die();
}

// API обработчики
if(isset($_POST['action'])){
    if($_POST['token'] != $_SESSION['token']){
        header($_SERVER["SERVER_PROTOCOL"]." 403 Forbidden", true, 403);
        die(); 
    }
    switch ($_POST['action']) {
        case "company_edit":
            $company = new Company($link, -1, -1, (int) $_GET['id']);
            $filters = $company->filters;
            $company_id = $company->id;
            $extra_fields = [];

            if(!$company){
                header("Location: /admin/");
                die();
            }

            if(!empty($_FILES['company_logo'])){
                $quality = 100;
                set_error_handler(function() { /* ignore errors */ });
                try{
                switch($_FILES['company_logo']['type']){
                        case 'image/jpeg': $source = imagecreatefromjpeg($_FILES['company_logo']['tmp_name']); break;
                        case 'image/png': $source = imagecreatefrompng($_FILES['company_logo']['tmp_name']); break;  
                        case 'image/gif': $source = imagecreatefromgif($_FILES['company_logo']['tmp_name']); break;
                        default: $quality = -1; break;
                    }
                } catch(Exception $ex){
                    $quality = -1;
                }
                if($quality > 0){
                    imagejpeg($source, $_SERVER["DOCUMENT_ROOT"] . "/img/companies/$company_id.jpg", $quality);
                    $_POST['company_logo'] = "$company_id.jpg";
                    imagedestroy($source);
                }
                restore_error_handler();
            }

            foreach($filters as $filter){
                if((int) $filter['type'] == 0){
                    if(isset($_POST['extra_'.$filter['name']])){
                        array_push($extra_fields, ["name" => $filter['name'], "value" => 1]);
                    }
                    else{
                        array_push($extra_fields, ["name" => $filter['name'], "value" => 0]);
                    }
                }
                else{
                    array_push($extra_fields, ["name" => $filter['name'], "value" => (int) $_POST['extra_'.$filter['name']]]);
                }
            }
            
            $extra_fields = json_encode($extra_fields);
            if(Company::Edit($link, $company_id, $_POST, $extra_fields)){
                $notify = '
                <div class="alert background-success notify">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <i class="icofont icofont-close-line-circled text-white"></i>
                    </button>   
                    <strong>Успех!</strong> Данные успешно сохранены</b>
                </div>';
            }
            else{
                $notify = '
                <div class="alert background-danger notify">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <i class="icofont icofont-close-line-circled text-white"></i>
                    </button>
                    
                    <strong>Провал.</strong> Произошла неизвестная ошибка, попробуйте позднее -> '.mysqli_error($link).'
                </div>';
            }
            break;
        default:
            break;
    }
}

$sql = Company::GetCityListSQL().Company::GetCompanyTypesSQL();
list($city_list, $company_types) = MultiQuery($link, $sql);

$company = new Company($link, -1, -1, (int) $_GET['id']);
$filters = $company->filters;
$company = $company->info;

if(!$company){
    header("Location: /admin/");
    die();
}

// print_r($company); echo("<br>");
// print_r($city_list); echo("<br>");
// print_r($company_types);

include("../views/admin_view/header.php"); 

include("../views/admin_view/edit_company.php");

include("../views/admin_view/footer.php"); 

?>